username = input("Enter username:")
password=input("Enter password:")
