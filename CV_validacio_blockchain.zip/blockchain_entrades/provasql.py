import sqlite3
from datetime import date
conn=sqlite3.connect('emails.db')

c=conn.cursor()

c.execute("""CREATE TABLE IF NOT EXISTS regEmails
            (adress text
            )""")


email='example@gmail.com'
c.execute("INSERT INTO regEmails VALUES (?)", (email,))
conn.commit()



#c.execute("INSERT INTO regEmails VALUES (:adress)", (email,))
#conn.commit()
          

c.execute("SELECT * FROM regEmails")
          
l=c.fetchall()


for elem in l:
    if elem[0]=='example@gmail.com':
        print('yes')
    else:
        pass

conn.commit()

conn.close()
